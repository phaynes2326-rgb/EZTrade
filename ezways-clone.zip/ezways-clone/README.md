# Deploy

1. Create a GitHub repository.
2. Upload these files.
3. Log into Vercel.
4. Import the GitHub repository.
5. Click Deploy.
