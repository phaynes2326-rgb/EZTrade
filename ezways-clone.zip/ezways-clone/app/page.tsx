
export default function Page(){
return <main style={{fontFamily:'Arial',padding:40,maxWidth:800,margin:'auto'}}>
<h1>EZ Ways To Trade</h1>
<p>Choose a platform below.</p>
<p><a href="https://my.veritymarkets.com/register?referral=019ef7ac-b4f3-70ee-98a5-4cc05a00df07">Join Verity Markets</a></p>
<p><a href="https://www.backatzero.io/ref/phaynes">Join Back At Zero Community</a></p>
</main>}
